﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Common.Utility.Encryption;
using Common.Utility.Models;
using Common.Utility.Models.HttpModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZxjcPlatform.IServices.IDbServices;

namespace ZxjcPlatform.ApiServices.DefaultApi
{
    /// <summary>
    /// 验证用户
    /// </summary>
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    [AllowAnonymous]//允许匿名访问
    public class VerifyUserController : ControllerBase
    {
        /// <summary>
        /// 用户信息服务
        /// </summary>
        public ISYSUserInfoService sysUserInfoService { get; set; }

        /// <summary>
        /// 验证用户
        /// </summary>
        /// <param name="key">账号</param>
        /// <param name="secret">密码</param>
        /// <returns></returns>
        [HttpGet("{key}/{secret}")]
        public async Task<IActionResult> Get(string key, string secret)
        {
            var apiData = new ApiResultModel();
            var rvu_data = await VerifyUser(key, secret);
            if (rvu_data == null)
            {
                apiData.Code = ErrorCodeType.KeyOrSecretError;
                return Ok(apiData);
            }
            apiData.Result = rvu_data;
            return Ok(apiData);
        }

        /// <summary>
        /// 验证用户
        /// </summary>
        /// <param name="key">账号</param>
        /// <param name="secret">密码</param>
        /// <returns></returns>
        private async Task<VerifyUserModel> VerifyUser(string key, string secret)
        {
            var pwd = key + secret;
            pwd = EncrypHelper.EncryptToMD5(pwd);
            var user = await sysUserInfoService.GetUserInfoModel(key, pwd);
            if (user == null)
            {
                //验证不通过
                return null;
            }

            var tokenUserJson = JsonSerializer.Serialize(new { key, secret });
            return new VerifyUserModel()
            {
                user_id = user.LoginCode,
                role_id = "none",
                role_name = user.Title,
                user_info = tokenUserJson
            };
        }
    }
}