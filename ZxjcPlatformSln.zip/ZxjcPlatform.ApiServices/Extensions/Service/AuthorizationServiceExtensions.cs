﻿using Common.Utility.Models.Config;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZxjcPlatform.ApiServices.Extensions.Service
{
    /// <summary>
    /// 授权认证
    /// </summary>
    public static class AuthorizationServiceExtensions
    {
        /// <summary>
        /// 添加授权策略
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddAuthorizationService(this IServiceCollection services)
        {
            var jwtBearer = StaticConfig.AppSettings.ServiceCollectionExtension.IdentityJwt.JwtBearer;
            return services.AddAuthorization(options =>
            {
                //在AddMvcService中添加授权过滤器
                //根据TOKEN携带的信息控制是否有权限
                {
                    //只要token携带就通过
                    options.AddPolicy("all_access", policy => policy.RequireClaim("scope"));
                    //读
                    options.AddPolicy("read_access", policy => policy.RequireClaim("scope", $"{jwtBearer.Audience}.read_access", $"{jwtBearer.Audience}.read_write_access"));
                    //写包含读
                    options.AddPolicy("read_write_access", policy => policy.RequireClaim("scope", $"{jwtBearer.Audience}.read_write_access"));
                }
            })
            ;
        }


        /// <summary>
        /// 添加认证服务
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddAuthenticationService(this IServiceCollection services)
        {
            var jwtBearer = StaticConfig.AppSettings.ServiceCollectionExtension.IdentityJwt.JwtBearer;
            services.AddAuthentication("Bearer")
                .AddJwtBearer("Bearer", options =>
                {
                    options.Authority = jwtBearer.Authority;
                    options.Audience = jwtBearer.Audience;
                    options.RequireHttpsMetadata = jwtBearer.RequireHttpsMetadata;
                });
            return services;
        }
    }
}
