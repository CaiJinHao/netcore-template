﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Autofac.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ZxjcPlatform.ApiServices.Extensions;
using Common.Utility.Extension;

namespace ZxjcPlatform.ApiServices
{
    /// <summary>
    /// Program
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            InitDirectory();
            CreateHostBuilder(args).Build().Run();
        }

        /// <summary>
        /// CreateHostBuilder
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseServiceProviderFactory(new AutofacServiceProviderFactory())
                .ConfigureLogging((loggingBuilder) =>
                {
                    //Replace the default Logging with Log4Net
                    loggingBuilder.AddLog4(ConfigurationsModel.Log4netConfig);
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    var _path = Directory.GetCurrentDirectory();
                    var config = new ConfigurationBuilder()
                                    .SetBasePath(_path)
                                    .AddJsonFile(ConfigurationsModel.HostSettings, optional: true)
                                    .AddCommandLine(args)
                                    .Build();
                    webBuilder.UseConfiguration(config);
                    webBuilder.ConfigureKestrel(serverOptions => {
                        serverOptions.Limits.MaxRequestBodySize = long.MaxValue;
                        serverOptions.Limits.MaxConcurrentConnections = long.MaxValue;
                    });
                    webBuilder.UseStartup<Startup>();
                });


        /// <summary>
        /// InitDirectory
        /// </summary>
        private static void InitDirectory()
        {
            var LogDirecotry = AppDomain.CurrentDomain.BaseDirectory + "/wwwroot/Log/";
            new FileInfo(LogDirecotry).Directory.CreateDirectoryInfo();
        }
    }
}
